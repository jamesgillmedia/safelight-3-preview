CKS Permanent Impermanence: upload set
Gill James

Web app (interactive work examples):
  https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/
  One-pager page:  https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/one.html
  Film page:       https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/film.html
  White Noise:     https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/noise.html
  Spirit Eye page: https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/spirit.html
  CV (web):        https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/cv/
  Arts / desktop CV: https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/cv/gill-james-arts-cv.pdf
  Mobile CV:       https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/cv/gill-james-cv-mobile.pdf
  Work examples PDF: https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/gill-james-work-examples.pdf
  One-page PDF:    https://jamesgillmedia.github.io/safelight-3-preview/t-43f1738a744a652baf18/gill-james-work-examples-one-page.pdf
  More: Spirit Eye, in 3D
    https://jamesgillmedia.github.io/gill-sky/u4-opus-m4/3d/

Files in this folder:
  gill-james-work-examples.pdf  (8.26 MB, 8659816 bytes, 14 pages)
  gill-james-work-examples-one-page.pdf  (3.97 MB, 4159590 bytes, 1 page)
  lost-in-time-lost-coffee.mp3  (8.24 MB, 8642490 bytes, 3:36)
  one-with-the-devil-excerpt.mp4  (21.79 MB, 22849254 bytes, 1:52, 1280x720)
  gill-james-arts-cv.pdf  (0.23 MB, 241883 bytes, 2 pages, Letter)
  gill-james-cv-mobile.pdf  (0.24 MB, 247481 bytes, 1 tall page, 390 pt)
  support-letter-krystal-paraboo.pdf  (0.09 MB, 98580 bytes, 1 page, Letter)
    Signed letter of support from Krystal Paraboo, Public Art Director, Black + Indigenous Design Collective, 25 November 2026. Included as signed.

Notes:
  Both CV PDFs use Crəə-Métis in the header and statement, to match the web CV. Norway House Cree Nation is unchanged. Official wording is otherwise the same. The Mark is live syllabics.
  The arts CV is the desktop Letter format. The mobile CV is a tall phone-width page (390 pt), meant to be read by zooming.
  The one-pager PDF is pad-sized (834 x 1194 pt) and denser, featuring the earlier main hanging sculpture photograph.
  Every PDF link in this set points at the preview folder t-43f1738a744a652baf18.
  The work examples PDF opens on a Spirit Eye forest garden frame, then groups the tray with the carved paddle, and includes a Forest garden page: one strong frame with the quiet layer words canopy, understory, ground, water, light, people. The same frame is on the web walkthrough, with the words slowly revealing.
  The cup from-above shot is not the lead in the curated PDFs or the one-pager; it is archive-only as a standalone cup view. Tray photographs appear with the paddles.
  Lost in Time is the official 3:36 tagged 320 kbps track (8642490 bytes).
  The Download all zip in this preview folder matches this set, including the signed support letter and the latest PDFs.
  No file in this set uses the word student. There are no em or en dashes in the user-facing copy we wrote. The signed support letter is included as signed.
  Earlier previews (do not overwrite): t-a3884dbac916d28ed1f3, t-a862466be3bc9febc14b, t-1f35a2bc17dcd75e6f91, t-a40eb3348ef0a696ce95, t-38a241a64628f14e551b, t-e866d21c2c45f89e9c32, t-004b89e6efdfdf86466e, t-7aad8f95bdd19c2273ba.
  Updated 4:09 PM America/Cambridge_Bay, 25 November 2026.
